package com.mycompany.ctis310hw4;

/**
 *
 * @author Austin
 */
public class InsertionSort {

    public static String InsertionSrt(int[] input) {
        String finalString = "";
        int temp;
        boolean is_sorted;
        
        for (int i = 1; i < input.length; i++) {
            is_sorted = true;
            for (int j = i; j > 0; j--) {
                if (input[j] < input[j - 1]) {
                    temp = input[j];
                    input[j] = input[j - 1];
                    input[j - 1] = temp;
                    is_sorted = false;
                    
                }
                
            }
            if(is_sorted) break;
            ArrayMethods.printArray(input);
            String tempArray = ArrayMethods.arrayToString(input);
            finalString = finalString + "Step " + ((i-1)+1) + ": " + tempArray + "\n\n";
        }

        return finalString;
    }

}

