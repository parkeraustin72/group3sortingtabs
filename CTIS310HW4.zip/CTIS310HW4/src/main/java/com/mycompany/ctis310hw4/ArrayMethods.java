
package com.mycompany.ctis310hw4;


public class ArrayMethods {
    
    
    
    public static void printArray(int [] input){
        for (int temp = 0; temp< input.length; temp++){
            System.out.print(input[temp] + " ");
        }
        System.out.println();
    }
    
}
